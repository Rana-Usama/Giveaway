export default Colors = {
  primary: "#3F8D79",
  darkOrange: "#D37C2C",
  green: "#4F8472",
  white: "#fff",
  black: "#000",
};
